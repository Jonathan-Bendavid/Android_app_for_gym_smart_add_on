package com.example.myapplication111;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private FirebaseDatabase database;
    private DatabaseReference workoutRef;
    private TextView workoutDataTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firebase
        database = FirebaseDatabase.getInstance();

        // Initialize TextView
        workoutDataTextView = findViewById(R.id.workoutDataTextView);

        // Clear data
        workoutDataTextView.setText("");

        // Fetch all users and set up a real-time listener for updates
        fetchAllUsersData();
    }

    //Method to fetch and listen for real-time data changes from the database

    private void fetchAllUsersData() {
        workoutRef = database.getReference("workoutData");

        // Set up a real-time listener to fetch data for all users
        workoutRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Clear previous data
                workoutDataTextView.setText("");

                // Go through the users
                for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    String userId = userSnapshot.getKey();
                    StringBuilder userData = new StringBuilder();

                    // Append user name
                    userData.append(userId).append("\n");

                    // Count the number of workouts for this user
                    int totalWorkouts = (int) userSnapshot.getChildrenCount();
                    userData.append("Total Workouts: ").append(totalWorkouts).append("\n");

                    // Get the most recent workout data for this user
                    getMostRecentWorkoutData(userSnapshot, userData);

                    // Append a gap
                    userData.append("\n");

                    // Display the complete workout data for the user
                    workoutDataTextView.append(userData.toString());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("Firebase", "Failed to read value.", databaseError.toException());
            }
        });
    }

     // Method to fetch and display the most recent workout data for a user

    private void getMostRecentWorkoutData(DataSnapshot userSnapshot, StringBuilder userData) {
        // Order the workouts by key and limit to the most recent one
        DataSnapshot latestWorkoutSnapshot = null;
        for (DataSnapshot workoutSnapshot : userSnapshot.getChildren()) {
            latestWorkoutSnapshot = workoutSnapshot;
        }

        if (latestWorkoutSnapshot != null) {
            // Get the date (key), exercise, sets, reps
            String date = latestWorkoutSnapshot.getKey();
            String exercise = getDataFromSnapshot(latestWorkoutSnapshot, "Exercize");
            String sets = getDataFromSnapshot(latestWorkoutSnapshot, "sets");
            String reps = getDataFromSnapshot(latestWorkoutSnapshot, "reps");

            // Append the most recent workout data to the StringBuilder
            userData.append("Date: ").append(date).append("\n");
            userData.append("Exercise: ").append(exercise).append("\n");
            userData.append("Sets: ").append(sets).append("\n");
            userData.append("Reps: ").append(reps).append("\n");
        } else {
            userData.append("No workout data available.\n");
        }
    }
    
     // Helper method to retrieve data from the DataSnapshot and return it as a String

    private String getDataFromSnapshot(DataSnapshot snapshot, String key) {
        try {
            // Try to get the value as an Integer
            Integer value = snapshot.child(key).getValue(Integer.class);
            if (value != null) {
                return String.valueOf(value); // Convert Integer to String
            }

            // If it's not an Integer, try to get it as a String
            String stringValue = snapshot.child(key).getValue(String.class);
            return stringValue != null ? stringValue : "Data not available";

        } catch (Exception e) {
            Log.e("Firebase", "Error retrieving key: " + key, e);
            return "Data not available";
        }
    }
}
